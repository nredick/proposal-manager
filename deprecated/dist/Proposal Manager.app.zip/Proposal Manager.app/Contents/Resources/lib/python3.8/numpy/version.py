
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.18.4'
version = '1.18.4'
full_version = '1.18.4'
git_revision = '94721320b1e13fd60046dc8bd0d343c54c2dd2e9'
release = True

if not release:
    version = full_version
